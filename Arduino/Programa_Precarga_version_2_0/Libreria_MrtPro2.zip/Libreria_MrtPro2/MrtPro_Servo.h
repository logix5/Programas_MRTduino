/**
 * @file     MrtServo.h
 * @version  v1.0.6
 * @date     2019.02.23
 *
 */
#ifndef MrtPro__SERVO_H
#define MrtPro__SERVO_H

#include <Arduino.h>
#include "MrtPro_Common.h"

// 아날로그 서보모터 관련
#define ANALOG_SERVO_MAX_PORT   4

typedef struct  {
    int8_t  index;
    struct {
        int8_t  pinNo;
        int     minPulse=100;
        int     maxPulse=2600;
        int     pulseWidth=0;
        long    lastPulse=0;
        int     preAngle=0;
        int     refreshTime=20;
    } data[ANALOG_SERVO_MAX_PORT];
}  st_analogServo;

extern volatile st_analogServo   analogServo;  // port9 ~ port11  (이전 angle때문에 각 포트별 보관하기로 함.)

class MrtServo {
public:
    // constructor
    MrtServo();

    /**
     * @brief  아날로그 서보 모터 초기화
     *
     * @param   int8_t         port_no    :  서보모터 포트번호
     *
     */
    void initServoMotor(int8_t port_no);

    /**
     * @brief  아날로그 서보 모터 초기화 (for pin)
     *
     * @param   uint8_t  servoPin   servo motor pin
     *
     */
    void initServoPin(uint8_t servoPin);

    /** @brief servo interrupt enable
     *
     */
    void servoEnable(void);

    /** @brief servo interrupt disable
     *
     */
    void servoDisable(void);

    /**
     * @brief   아날로그 서보모터 구동
     *
     * @param   int16_t         angle     :  각도 (-150 ~ 150)
     * @param   uint8_t         speed     :  속도 (0, 25, 50, 75, 100)
     */
    void runServoMotor(int16_t angle, uint8_t speed);

    /**
     * @brief   아날로그 서보모터 구동
     *
     * @param   uint8_t         port_no    :  서보모터 포트번호
     * @param   int16_t         angle     :  각도 (-150 ~ 150)
     * @param   uint8_t         speed     :  속도 (0, 25, 50, 75, 100)
     */
    void runServoMotor(uint8_t port_no, int16_t angle, uint8_t speed);

    /**
     * @brief  서보모터 정지
     *
     */
    void stopServoMotor();

private:
    bool _servoEnable = false;      // 서보 사용 가능 여부
};

#endif // MRT_SERVO_H
