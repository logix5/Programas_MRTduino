
//#include "MRT_X.h"

#include "MrtPro_LineTracking.h"
//#include "arduino1/Arduino.h"




void _delay_ms1(int ms)
{
	delay(ms);
}

void _delay_us1(int ms)
{
	delayMicroseconds(ms);
	
}


unsigned int LineSensorState = 0x1C;
//unsigned int I2C_flag = 0;

volatile byte buffer[2]={0x1B};

static const byte address=8;


/*******************************************************************************
* Description  :
* Input  param :
* Output param :
* Detail       :
*******************************************************************************/


void Init_track(void){
  Wire.begin(address);           // join i2c bus with address #8
  Wire.onReceive(receiveEvent); // register event
  SoftPWMBegin();


}


void line_start(void){
	
	delay(1);
}


void DC_Motor(byte Inputp,int speed){
  byte PinNo=-1;
  
  if (Inputp < 1) return;
  else PinNo = Inputp - 1;

  int motorPins[4][2] = {{21, 7}, {20, 4}, {1, 8}, {0, 6}};

  pinMode(motorPins[PinNo][0], OUTPUT);
  pinMode(motorPins[PinNo][1], OUTPUT);

  if (speed <= 0) digitalWrite(motorPins[PinNo][0], LOW); // backward
  else digitalWrite(motorPins[PinNo][0], HIGH);           // forward

  SoftPWMSet(motorPins[PinNo][1], abs(speed));

}


void DC_Double_Motor(byte Inputp1,int speed1,byte Inputp2,int speed2){
	
	  DC_Motor(Inputp1,speed1);
	  DC_Motor(Inputp2,speed2);
		
}

void DC_Double_Motor_time(byte Inputp1,int speed1,byte Inputp2,int speed2,int time){
	
	  DC_Motor(Inputp1,speed1);
	  DC_Motor(Inputp2,speed2);
	  delay(time);
		
}

void startend(int staus)
{
	if(staus==1)         //开始巡线
	{
		
	    DC_Motor(3,100);
	    DC_Motor(4,100);
	}
	else				//结束巡线
	{
		
	    DC_Motor(3,0);
	    DC_Motor(4,0);
	}
	
}



void receiveEvent(int howMany) {
 

	  //I2C_flag=1;
	  for( int i=0; i<howMany; i++){
         buffer[i] = Wire.read();
 
   }
  
	
}


void Line_Sensor_Turn(int L_F_Motor_Speed,int R_F_Motor_Speed,int xSensor,int counter,int delay_time)
{
	unsigned int LineSensorNewStateTemp = 0;
	unsigned int LineSensorOldStateTemp = 0;
	unsigned int temp = 0;
	
	if(xSensor == 0)  { temp = 0x10; }
	if(xSensor == 1)     { temp = 0x08; }
	if(xSensor == 2)   { temp = 0x04; }
	if(xSensor == 3)    { temp = 0x02; }
	if(xSensor == 4) { temp = 0x01; }

	counter *=2;
	
	LineSensorOldStateTemp = Line_Sensor_GetValue() & temp;
	
	
	if(LineSensorOldStateTemp) {counter -= 1;}
	
	while(counter)
	{
		LineSensorNewStateTemp = Line_Sensor_GetValue() & temp;
		
		if(LineSensorNewStateTemp != LineSensorOldStateTemp){ counter--; }
		
		LineSensorOldStateTemp = LineSensorNewStateTemp;
		DC_Motor(3,L_F_Motor_Speed);
		DC_Motor(4,R_F_Motor_Speed);
		
	}

	DC_Motor(3,0);
	DC_Motor(4,0);
	_delay_ms1(delay_time);
	

}




void Line_Sensor_Turn_two(int L_F_Motor_Speed,int R_F_Motor_Speed,int xSensor,int ySensor,int delay_time)
{
	 Line_Sensor_Turn( L_F_Motor_Speed, R_F_Motor_Speed, xSensor,1, delay_time);
	 delay(1);
	 Line_Sensor_Turn(L_F_Motor_Speed, R_F_Motor_Speed, ySensor, 1, delay_time);
}





/*******************************************************************************
* Description  :
* Input  param : 
* Output param : 
* Detail       :
*******************************************************************************/

bool Line_Sensor_JudgeState(int OutLeftState,int LeftState,int MiddleState,int RightState,int OutRightState)
{
	
	unsigned char LineSensorStateTemp = Line_Sensor_GetValue();
	  	
	//------------------------------------------------
	if(OutRightState == 0)
	{
		if(!(LineSensorStateTemp & 0x01)){return 0;}
	}
	else if(OutRightState == 1)
	{
		if(LineSensorStateTemp & 0x01){return 0;}
	}
	//-----------------------------------------------
	LineSensorStateTemp >>= 1;
	if(RightState == 0)
	{
		if(!(LineSensorStateTemp & 0x01)){return 0;}
	}
	else if(RightState == 1)
	{
		if(LineSensorStateTemp & 0x01){return 0;}
	}
	//-----------------------------------------------
	LineSensorStateTemp >>= 1;
	if(MiddleState == 0)
	{
		if(!(LineSensorStateTemp & 0x01)){return 0;}
	}
	else if(MiddleState == 1)
	{
		if(LineSensorStateTemp & 0x01){return 0;}
	}
	//-----------------------------------------------
	LineSensorStateTemp >>= 1;
	if(LeftState == 0)
	{
		if(!(LineSensorStateTemp & 0x01)){return 0;}
	}
	else if(LeftState == 1)
	{
		if(LineSensorStateTemp & 0x01){return 0;}
	}
	//-----------------------------------------------
	LineSensorStateTemp >>= 1;
	if(OutLeftState == 0)
	{
		if(!(LineSensorStateTemp & 0x01)){return 0;}
	}
	else if(OutLeftState == 1)
	{
		if(LineSensorStateTemp & 0x01){return 0;}
	}
		
	return 1;	
}




int Line_Sensor_GetValue(void)
{
   
	return buffer[0];

}



void line_track_mode(int lspeed1,int rspeed1,int lspeed2,int rspeed2,int lspeed3,int rspeed3,int lspeed4,int rspeed4,int lspeed5,int rspeed5)
{
	
	
	 if( Line_Sensor_JudgeState(2,0,1,0,2)){
        DC_Double_Motor(3,lspeed1,4,rspeed1);
    }
    if( Line_Sensor_JudgeState(2,1,1,0,2)){
        DC_Double_Motor(3,lspeed2,4,rspeed2);
    }
    if( Line_Sensor_JudgeState(2,1,0,0,2)){
        DC_Double_Motor(3,lspeed3,4,rspeed3);
    }
    if( Line_Sensor_JudgeState(2,0,1,1,2)){
        DC_Double_Motor(3,lspeed4,4,rspeed4);
    }
    if( Line_Sensor_JudgeState(2,0,0,1,2)){
        DC_Double_Motor(3,lspeed5,4,rspeed5);
    }
}

