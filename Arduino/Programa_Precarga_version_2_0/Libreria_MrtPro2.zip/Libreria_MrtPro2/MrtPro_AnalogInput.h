/**
 * @file     MrtAnalogInput.h
 * @version  v0.6.0
 * @date     2016.12.29
 *
 */
#include "MrtPro_Common.h"

#ifndef MRT_ANALOG_INPUT_H
#define MRT_ANALOG_INPUT_H

#define FLAG_SENSE_LTE      1   // sensor_value >= threshold 일때 감지된 것으로 인식되는 센서의 경우
#define FLAG_SENSE_LARGE    2   // sensor_value >  threshold 일때 감지된 것으로 인식되는 센서의 경우
#define FLAG_SENSE_EQUAL    3   // sensor_value =  threshold 일때 감지된 것으로 인식되는 센서의 경우
#define FLAG_SENSE_SMALL    4   // sensor_value <  threshold 일때 감지된 것으로 인식되는 센서의 경우
#define FLAG_SENSE_STE      5   // sensor_value <= threshold 일때 감지된 것으로 인식되는 센서의 경우


#define THRESHOLD_VIBRATION 60      // readValue <= 60 경우 감지된것으로 인식
#define THRESHOLD_MIC       1000    // analog input (input_pullup 모드) mrt에서 제시한 값은 7
#define THRESHOLD_CDS       600     // Threshold  35>=x <600(LIGHT SENSED),  State:  LIGHT/ DARK
#define THRESHOLD_IR        250     // 이보다 낮은 값일때 감지된 것으로 인식.
#define THRESHOLD_FLAME     900     // 테스트 결과 450이상 (평상시 200~418, 밝은 led 빛에서 990까지 측정됨)

class MrtAnalogInput {
public:
    MrtAnalogInput();

    /**
     * @brief  센서 초기화
     *
     * @param   int port_no    : 포트 번호
     *
     */
    MrtAnalogInput(int port_no);

    /**
     * @brief  센서 초기화
     *
     * @param   uint8_t port_no    : 포트 번호
     * @param   int     threshold  : 감지여부 기준값
     * @param   int8_t  flag       : 기준값보다 많을때 감지하는지 적을때 감지하는지 flag
     *
     */
    MrtAnalogInput(int8_t port_no, int threshold, int8_t flag);

    /**
     * @brief  센서 초기화
     *
     * @param   uint8_t port_no    : 포트 번호
     * @param   int     threshold  : 감지여부 기준값
     * @param   int8_t  flag       : 기준값보다 많을때 감지하는지 적을때 감지하는지 flag
     *
     */
    void initAnalogInput(int8_t port_no, int threshold, int8_t flag);

    /**
     * @brief  센서 초기화
     *
     * @param   uint8_t port_no    : 포트 번호
     *
     */
    void initAnalogInput(int8_t port_no);

    /**
     * @brief  센서 초기화
     *
     * @param   uint8_t port_no    : 포트번호
     * @param   int     threshold  : 감지여부 기준값
     * @param   int8_t  flag       : 기준값보다 많을때 감지하는지 적을때 감지하는지 flag
     *
     */
    void initAnalogInputPullup(int8_t port_no, int threshold, int8_t flag);
    /**
     * @brief  센서값 읽은 후 감지여부 체크
     *
     * @param    bool  flag : 감지(1)/미감지(0) 여부 체크함.
     * @return   bool  ret  : flag값 체크 결과
     *
     */
    bool isSensed(bool flag);
    /**
     * @brief   감지여부 체크
     *
     * @param   int   val  : 센서값
     * @return  bool  ret  : 감지여부 (ANALOG_INPUT_SENSED/ANALOG_INPUT_NO_SENSED)
     *
     */
    bool checkSensed(int val);

    /**
     * @brief  센서값 감지여부 (디지털)
     *
     * @param    bool  flag : 감지(1)/미감지(0) 여부 체크함.
     * @return   bool  ret  : flag값 체크 결과
     *
     */
    bool isDigitalSensed(bool flag);

    /**
     * @brief  센서값 감지여부, counter (디지털)
     *
     * @param    bool       flag    감지(1)/미감지(0) 여부 체크함.
     * @param    uint8_t    cnt     감지 횟수
     * @param    uint8_t    time    감지 시간
     * @return   bool       ret     flag값 체크 결과
     *
     */
    bool isDigitalSensed(bool flag, uint8_t cnt, uint8_t time);

    /**
     * @brief  vibration sensor check, counter (analog)
     *
     * @param    bool       flag    감지여부, 감지=1/미감지=0
     * @param    uint8_t    cnt     감지 횟수, default 0
     * @param    uint8_t    time    감지 시간, default 1 sec
     * @param    uint8_t    threshold   감지 기준값, default 60
     * @return   bool       flag값 체크 결과
     *
     */
    bool isSensedVibration(bool flag, uint8_t cnt=0, uint8_t time=1, uint8_t threshold=THRESHOLD_VIBRATION);

    /**
     * @brief   감지여부 체크
     *
     * @param   uint8_t operation   연산자 1:>=, 2:>, 3:=, 4:<, 5:<=
     * @param   int     threshold   감지기준
     * @param   uint8_t detectCond  감지(1)/미감지(0)
     * @return  bool    감지여부
     *
     */
    bool checkSensed(uint8_t operation, int threshold, uint8_t detectCond);

    /**
     * @brief  설정된 감지여부 기준값 읽기
     *
     * @return   int    _threshold  : 설정된 감지여부 기준값
     *
     */
    int  getThreshold();
    /**
     * @brief  감지여부 기준값 설정
     *
     * @param   int     threshold  : 감지여부 기준값
     *
     */
    void setThreshold(int threshold);
    /**
     * @brief   센서값 읽기
     *
     * @return  int  val  : 센서값
     *
     */
    int  readValue();

private:
    int8_t  _pinNo;
    int     _threshold;
    int8_t  _flag;
};

#endif // MRT_ANALOG_INPUT_H


