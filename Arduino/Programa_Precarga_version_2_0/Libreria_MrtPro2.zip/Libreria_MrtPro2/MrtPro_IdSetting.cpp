/*************************************************************************
* File Name          : MrtIdSetting.cpp
* Author             : Steve
* Updated            : Steve
* Version            : V1.0000
* Date               : 02/24/2016
* Description        : MRT ID Setting .
* License            : Solbea
* Copyright (C) 2014 - 2016 Solbea Ltd. All right reserved.
* steve at solbea dot com
*
*		        DIP(3pin)             Startbutton
*Name:       ID1      ID2     ID3          SW
*Port:       (22)     (22)     (23)       (23)
*Macro:     ID1ON    ID2ON    ID3ON      STARTON
*
**************************************************************************/
/**
* @date     2016.09.23
* @details  MRT IR receiver ID 값 읽기 \n
*           modified ReadId()
*/
#include "MrtPro_IdSetting.h"
#include "MrtPro_Duino.h"
#include <Arduino.h>

/**
 * @brief   constructor
 */
MrtIdSetting::MrtIdSetting() {}

/**
 * @brief   constructor
 * @param   int sampling   :  반복횟수
 */
MrtIdSetting::MrtIdSetting(int sampling)
{
	this->sampling = sampling;
}

/**
 * @brief   IR Receiver ID 값 읽기 (보드에 dip switch로 설정)
 *
 * @param   int sampling    체크횟수 (정확도위해), default 10
 * @return  int id          보드에 설정된 ID값
 * @details get much precise value, collect 10 times values. (default)
*/
int MrtIdSetting::ReadId(int sampling) // get more sample to determine analogpin input status.
{
	unsigned char dip1, dip2, dip3;
	int sum1=0, sum2=0, sum3=0;
	int id=-1;
	for(int j=0; j<sampling;j++){
			dipswpin1=ID1ON;
			sum1 += dipswpin1;
			dipswpin2=ID2ON;
			sum2 += dipswpin2;
			dipswpin3=ID3ON;
			sum3 += dipswpin3;
	}
	dipswpin1 = constrain(sum1, 0,1);
	dipswpin2 = constrain(sum2, 0,1);
	dipswpin3 = constrain(sum3, 0,1);

	dipswpin1?dip1=0x1:dip1=0x0;
	dipswpin2?dip2=0x2:dip2=0x0;
	dipswpin3?dip3=0x4:dip3=0x0;

    id = (dip1|dip2|dip3) + 1;
	return( id );
}


/**
 * @brief   보드의 START버튼이 눌렸는지 체크
 *
 * @param   int    flag : 눌림(1)/해제(0), default 1, pressed
 * @return  bool   true : flag가 1이고, start버튼이 눌렸을 때 \n
 *                        flag가 0이고, start버튼이 해제되었을 때 \n
 *                false : flag가 1이고, start버튼이 해제되었을 때 \n
 *                        flag가 0이고, start버튼이 눌렸을 때
 */
bool MrtIdSetting::isStartPressed(int flag)
{
    int sum=0, sw=0;

    for(int i=0; i<5; i++)      // 정확안 값을 가져오기 위해 여러 번 반복. 너무 늦으면 횟수 조정 가능
    {
        sum += STARTON;
    }
    sw = constrain(sum, 0, 1);
    if( flag == sw )    return true;
    else                return false;
}
