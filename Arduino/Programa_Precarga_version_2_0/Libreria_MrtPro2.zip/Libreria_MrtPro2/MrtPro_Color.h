/**
   @file    :   MrtColor.cpp
   @version :   v0.3.0
   @date    :   2018.05.04
   @details :   컬러센서 제어 \n
                out_port는 PORT 13 ~ PORT 16만 가능 (외부인터럽트 사용) \n
                S0, S1 - (LOW, HIGH) -> 2% OUTPUT FREQUENCY \n
                S2,S3(LOW,LOW)   -> RED \n
                S2,S3(HIGH, HIGH)-> GREEN \n
                S2,S3(LOW, HIGH) -> BLUE \n
                S2,S3(HIGH, LOW) -> No filter
*/
#ifndef MRT_COLOR_H
#define MRT_COLOR_H
#include <Arduino.h>
#include "MrtPro_Common.h"

#define RED 1
#define GREEN 2
#define BLUE 3

class MrtColorSensor {
  public:
    MrtColorSensor();
    void initColorSensorPin();
    void colorDisable();
    int getColor(int color);  // 1: red, 2: green, 3: blue

  private:

    int redFrequency;
    int greenFrequency;
    int blueFrequency;

    int redColor;
    int greenColor;
    int blueColor;

    int returnValue;
};
#endif // MRT_COLOR_H
