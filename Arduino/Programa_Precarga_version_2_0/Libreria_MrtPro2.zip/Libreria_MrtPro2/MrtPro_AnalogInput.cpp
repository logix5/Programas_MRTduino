/**
 * @file        MrtAnalogInput.cpp
 * @version     v0.6.0
 * @date        2016.12.29
 * @details     일반적인 Analog Input Sensor 정의 \n
 *              io type : Analog INPUT \n
 *              value scope : 0~1023
 *
 */

#include "MrtPro_AnalogInput.h"

MrtAnalogInput::MrtAnalogInput() {}

/**
 * @brief  센서 초기화
 *
 * @param   int port_no    : 포트 번호
 *
 */
MrtAnalogInput::MrtAnalogInput(int port_no) {
    initAnalogInput(port_no);
}

/**
 * @brief  센서 초기화
 *
 * @param   uint8_t port_no    : 포트 번호
 * @param   int     threshold  : 감지여부 기준값
 * @param   int8_t  flag       : 기준값보다 많을때 감지하는지 적을때 감지하는지 flag
 *
 */
MrtAnalogInput::MrtAnalogInput(int8_t port_no, int threshold, int8_t flag)
{
    initAnalogInput(port_no, threshold, flag);
}


/**
 * @brief  센서 초기화
 *
 * @param   uint8_t port_no    : 포트 번호
 * @param   int     threshold  : 감지여부 기준값, default=0
 * @param   int8_t  flag       : 기준값보다 많을때 감지하는지 적을때 감지하는지 flag, default=1
 *
 */
void MrtAnalogInput::initAnalogInput(int8_t port_no, int threshold, int8_t flag)
{
    _pinNo = convertPinNumberInt(port_no);
    _threshold = threshold;
    _flag = flag;
    if( _pinNo >= 0)     pinMode(_pinNo, INPUT);
}

/**
 * @brief  센서 초기화
 *
 * @param   uint8_t port_no    : 포트 번호
 *
 */
void MrtAnalogInput::initAnalogInput(int8_t port_no)
{
    _pinNo = convertPinNumberInt(port_no);
    if( _pinNo >= 0)     pinMode(_pinNo, INPUT);
}

/**
 * @brief  센서 초기화
 *
 * @param   uint8_t port_no    : 포트번호
 * @param   int     threshold  : 감지여부 기준값
 * @param   int8_t  flag       : 기준값보다 많을때 감지하는지 적을때 감지하는지 flag
 *
 */
void MrtAnalogInput::initAnalogInputPullup(int8_t port_no, int threshold, int8_t flag)
{
    _pinNo = convertPinNumberInt(port_no);
    _threshold = threshold;
    _flag = flag;
    if( _pinNo >= 0)     pinMode(_pinNo, INPUT_PULLUP);
}

/**
 * @brief  감지여부 기준값 설정
 *
 * @param   int     threshold   감지여부 기준값
 *
 */
void MrtAnalogInput::setThreshold(int threshold){
    _threshold = threshold;
}

/**
 * @brief  설정된 감지여부 기준값 읽기
 *
 * @return   int     _threshold  : 설정된 감지여부 기준값
 *
 */
int MrtAnalogInput::getThreshold()
{
    return _threshold;
}

/**
 * @brief  센서값 읽은 후 감지여부 체크
 *
 * @param    bool  flag : 감지(1)/미감지(0) 여부 체크함.
 * @return   bool  ret  : flag값 체크 결과
 *
 */
bool MrtAnalogInput::isSensed(bool flag){
    int val;
    bool ret;

    val = analogRead(_pinNo);
    
    ret = checkSensed(val);
    if( flag == ret )   return true;
    else                return false;
}

/**
 * @brief  센서값 감지여부 (디지털)
 *
 * @param    bool  flag : 감지(1)/미감지(0) 여부 체크함.
 * @return   bool  ret  : flag값 체크 결과
 *
 */
bool MrtAnalogInput::isDigitalSensed(bool flag) {
    int8_t val = digitalRead(_pinNo);

    if(val == flag) {
        return true;
    }
    else {
        return false;
    }
    return false;
}

/**
 * @brief  센서값 감지여부, counter (디지털)
 *
 * @param    bool       flag    감지(1)/미감지(0) 여부 체크함.
 * @param    uint8_t    cnt     감지 횟수
 * @param    uint8_t    time    감지 시간
 * @return   bool       ret     flag값 체크 결과
 *
 */
bool MrtAnalogInput::isDigitalSensed(bool flag, uint8_t cnt, uint8_t time) {
    uint16_t delayTime = int((time * 1000) / cnt);

    uint8_t i = 0, readVal = 0;

    for (i=0; i<cnt; i++) {
        readVal += constrain(digitalRead(_pinNo), 0, 1);
        delay(delayTime);
    }

    bool result = false;
    // true, sensed
    if (flag) {
        if (readVal == cnt) result = true;
        else result = false;
    }
    // false, nosensed
    else {
        if (readVal == 0) result = true;
        else result = false;
    }

    return result;
}

/**
 * @brief  vibration sensor check, counter (analog)
 *
 * @param    bool       flag    감지여부, 감지=1/미감지=0
 * @param    uint8_t    cnt     감지 횟수, default 0
 * @param    uint8_t    time    감지 시간, default 1 sec
 * @param    uint8_t    threshold   감지 기준값, default 60
 * @return   bool       flag값 체크 결과
 *
 */
bool MrtAnalogInput::isSensedVibration(bool flag, uint8_t cnt, uint8_t time, uint8_t threshold) {
    uint8_t readVal = 0;

    // couter block
    if (cnt > 0) {
        uint16_t delayTime = int((time * 1000) / cnt);
        uint8_t i = 0, senseCount = 0;

        for (i=0; i<cnt; i++) {
            readVal = analogRead(_pinNo);

            // readval <= 60, sensed
            if ((flag == true) && (readVal <= threshold)) senseCount++;
            else if ((flag == false) && (readVal > threshold)) senseCount++;

            delay(delayTime);
        }

        if (senseCount == cnt) return true;
        else return false;
    }
    // check sensed (default)
    else {
        readVal = analogRead(_pinNo);

        // readval <= 60, sensed
        if ((flag == true) && (readVal <= threshold)) return true;
        else if ((flag == false) && (readVal > threshold)) return true;
        else return false;
    }
    return false;
}

/**
 * @brief   감지여부 체크
 *
 * @param   int   val  : 센서값
 * @return  bool  ret  : 감지여부 (ANALOG_INPUT_SENSED/ANALOG_INPUT_NO_SENSED)
 *
 */
bool MrtAnalogInput::checkSensed(int val)
{
    if( val < 0)    return ANALOG_INPUT_NO_SENSED;
    if( ((_flag == FLAG_SENSE_LTE)   && (val >= _threshold)) ||
        ((_flag == FLAG_SENSE_LARGE) && (val > _threshold)) ||
        ((_flag == FLAG_SENSE_EQUAL) && (val == _threshold)) ||
        ((_flag == FLAG_SENSE_SMALL) && (val < _threshold)) ||
        ((_flag == FLAG_SENSE_STE)   && (val <= _threshold))  )
    {
        return ANALOG_INPUT_SENSED;
    } else {
        return ANALOG_INPUT_NO_SENSED;
    }
}

/**
 * @brief   감지여부 체크
 *
 * @param   uint8_t operation   연산자 1:>=, 2:>, 3:=, 4:<, 5:<=
 * @param   int     threshold   감지기준
 * @param   uint8_t detectCond  감지(1)/미감지(0)
 * @return  bool    감지여부
 *
 */
bool MrtAnalogInput::checkSensed(uint8_t operation, int threshold, uint8_t detectCond) {
    unsigned char state;
    detectCond = constrain(detectCond, 0, 1);
    operation = constrain(operation, 0, 5);
    if (operation < 1) return false;

    int val = readValue();
    if (((operation == FLAG_SENSE_LTE)   && (val >= threshold)) ||
        ((operation == FLAG_SENSE_LARGE) && (val > threshold)) ||
        ((operation == FLAG_SENSE_EQUAL) && (val == threshold)) ||
        ((operation == FLAG_SENSE_SMALL) && (val < threshold)) ||
        ((operation == FLAG_SENSE_STE)   && (val <= threshold))) {
        state = ANALOG_INPUT_SENSED;
    }
    else {
        state = ANALOG_INPUT_NO_SENSED;
    }

    if (detectCond == state) {
        return true;
    }
    else {
        return false;
    }
}

/**
 * @brief   센서값 읽기
 *
 * @return  int  val  : 센서값
 *
 */
int  MrtAnalogInput::readValue()
{
    int val = analogRead(_pinNo);
    
    return val;
}




