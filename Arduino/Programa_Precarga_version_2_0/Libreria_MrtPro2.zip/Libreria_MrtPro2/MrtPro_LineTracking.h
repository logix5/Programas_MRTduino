#ifndef __MrtPro_LINETRACKING_H__
#define __MrtPro_LINETRACKING_H__


#include <Wire.h>
#include <arduino.h>
//#include "MRT6.h"
#include "MrtPro_Motor.h"

typedef enum
{
	White,
	Black,
	Indeterminate ,
}SensorState;

typedef enum
{
	Out_Left_Sensor,
	Left_Sensor,
	Middle_Sensor,
	Right_Sensor,
	Out_Right_Sensor,
	
}XSensor;

enum Motor_Number
{
	L1_Motor,
	R1_Motor,
	L2_Motor,
	R2_Motor
};

extern unsigned int LineSensorState ;
extern unsigned char flag ;


void Init_track(void);//寻线初始化 IIC 初始化
void receiveEvent(int howMany);//IIC接收函数

void DC_Double_Motor(byte Inputp1,int speed1,byte Inputp2,int speed2);
void DC_Double_Motor_time(byte Inputp1,int speed1,byte Inputp2,int speed2,int time);

void DC_leftright_Motor(int speed1,int speed2);
void DC_leftright_Motor_time(int speed1,int speed2,int time);

	
void line_start(void);
void startend(int staus);
void _delay_ms1(int ms);
void _delay_us1(int ms);
bool Line_Sensor_JudgeState(int OutLeftState,int LeftState,int MiddleState,int RightState,int OutRightState);
int  Line_Sensor_GetValue();//获取寻线值

int Remocon_GetValue(void);//获取遥控器值

void Line_Sensor_Turn(int L_F_Motor_Speed,int R_F_Motor_Speed,int xSensor,int counter,int delay_time);
void Line_Sensor_Turn_two(int L_F_Motor_Speed,int R_F_Motor_Speed,int xSensor,int ySensor,int delay_time);
//void Line_Sensor_Turn_two(int L_F_Motor_Speed,int R_F_Motor_Speed,int xSensor,int ySensor,int counter,int delay_time);

void line_track_mode(int lspeed1,int rspeed1,int lspeed2,int rspeed2,int lspeed3,int rspeed3,int lspeed4,int rspeed4,int lspeed5,int rspeed5);
void line_track_4mode(int lspeed1,int rspeed1,int lspeed2,int rspeed2,int lspeed3,int rspeed3,int lspeed4,int rspeed4,int lspeed5,int rspeed5);
void Line_Sensor_Turn_4Motor(int L_Motor_Speed,int R_Motor_Speed,int xSensor,int counter,int delay_time);

void Line_Sensor_Turn_four(int L_F_Motor_Speed,int R_F_Motor_Speed,int xSensor,int ySensor,int delay_time);
void Line_Sensor_Turn4(int L_F_Motor_Speed,int R_F_Motor_Speed,int xSensor,int counter,int delay_time);
#endif