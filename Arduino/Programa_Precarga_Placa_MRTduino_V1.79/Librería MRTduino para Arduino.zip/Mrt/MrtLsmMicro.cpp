/**
 * @file     MrtLsmMicro.cpp
 * @author   keunja kim
 * @version  v0.4.0
 * @date     2017.03.23
 * @details  LSM-micro servo
 */
#include "MrtLsmMicro.h"

// contructor
MrtLsmMicro::MrtLsmMicro() {
    pinMode(kDirPin, OUTPUT);
}

MrtLsmMicro::MrtLsmMicro(uint8_t moduleID) {
    pinMode(kDirPin, OUTPUT);
    _lsmWrite.Module_ID = moduleID;
}

/**
 * @brief  send packet
 *
 *
 */
void MrtLsmMicro::lsmSend() {
    digitalWrite(kDirPin, HIGH);    // direction sent from Arduino UART TX

    _micro_write[0] = _lsmWrite.Header;
    _micro_write[1] = _lsmWrite.Product_ID;
    _micro_write[2] = _lsmWrite.Module_ID;
    _micro_write[3] = _lsmWrite.Instruction;
    _micro_write[4] = _lsmWrite.Parameter1;
    _micro_write[5] = _lsmWrite.Parameter2;
    _micro_write[6] = _lsmWrite.Parameter3;
    _micro_write[7] = (_lsmWrite.Module_ID + _lsmWrite.Instruction + _lsmWrite.Parameter1 + _lsmWrite.Parameter2 + _lsmWrite.Parameter3) & 0xFF;
    
    // send data
    for (uint8_t i=0; i<8; i++) {
        Serial1.write(_micro_write[i]);
    }
}

/**
 * @brief  recieve packet
 *
 *
 */
void MrtLsmMicro::lsmGet() {
    digitalWrite(kDirPin, LOW);

    memset(_micro_recieve, 0, 8);
    char c;
    uint8_t bitpos = 0;

    while (Serial1.available()) {
        c = Serial1.read();

        if (bitpos < 8) {
            _micro_recieve[bitpos] = c & 0xff;
            bitpos++;
        }
        else {
            break;
        }
    }
    Serial.flush();
}

/**
 * @brief  get value check
 *
 *
 */
long MrtLsmMicro::valueCheck() {
    long value = 0;
    if (_micro_recieve[3] == 0x13) {
        value = (_micro_recieve[4] << 8 | _micro_recieve[5]);
        value = (value << 8 | _micro_recieve[6]);
        
    }
    else if (_micro_recieve[3] == 0x10) {
        Serial.print("R: ");
        Serial.print(_micro_recieve[4]);
        Serial.print(" / G: ");
        Serial.print(_micro_recieve[5]);
        Serial.print(" / B: ");
        Serial.print(_micro_recieve[6]);

    }
    else {
        value = (_micro_recieve[4] << 8 | _micro_recieve[5]);
        value = (value << 8 | _micro_recieve[6]);
        
    }

    return value;
}

/**
 * @brief  get Module ID, 0-253, 2byte
 *
 *
 */
uint8_t MrtLsmMicro::getModuleID() {
    _lsmWrite.Instruction = 0x01;
    _lsmWrite.Parameter1 = 0;
    _lsmWrite.Parameter2 = 0;
    _lsmWrite.Parameter3 = 0;

    
    long value = 0;
    while (1) {
        // sampling 2
        delay(2);
        lsmSend();
        lsmGet();
        delay(2);
        lsmSend();
        lsmGet();

        value = valueCheck();

        if ((value>=0) && (_micro_recieve[3]==_lsmWrite.Instruction)) break;
        else continue;
    }

    return (uint8_t)value;
}

/**
 * @brief  get Module ID, 0-253, 2byte
 *
 * @return baudrate 2400 ~ 1000000 bps
 */
unsigned long MrtLsmMicro::getBaudrate() {
    _lsmWrite.Instruction = 0x13;
    _lsmWrite.Parameter1 = 0;
    _lsmWrite.Parameter2 = 0;
    _lsmWrite.Parameter3 = 0;

    long value = 0;
    while (1) {
       // sampling 2
        delay(2);
        lsmSend();
        lsmGet();
        delay(2);
        lsmSend();
        lsmGet();

        value = valueCheck();

        if ((value>0) && (_micro_recieve[3]==_lsmWrite.Instruction)) break;
        else continue;
    }

    return (unsigned long)value;
}

/**
 * @brief  Action EEP PROG Config Data
 *
 *
 */
void MrtLsmMicro::EEPconfig() {
    _lsmWrite.Instruction = 0x81;
    _lsmWrite.Parameter1 = 1;
    _lsmWrite.Parameter2 = 2;
    _lsmWrite.Parameter3 = 3;

    lsmSend();
}

/**
 * @brief  Action Move T_Position
 *
 * @param   uint8_t torque       0-250
 * @param   int16_t tPosition   target position, -500~500
 *
 */
void MrtLsmMicro::moveTposition(uint8_t torque, int16_t tPosition) {
    _lsmWrite.Instruction = 0x82;
    _lsmWrite.Parameter1 = torque;
    _lsmWrite.Parameter2 = tPosition>>8;
    _lsmWrite.Parameter3 = tPosition;

    lsmSend();
}

/**
 * @brief  Action Move T_Position
 *
 * @param   uint8_t moduleID     1-20
 * @param   uint8_t torque       0-250
 * @param   int16_t tPosition   target position, -500~500
 *
 */
void MrtLsmMicro::moveTposition(uint8_t moduleID, uint8_t torque, int16_t tPosition) {
    _lsmWrite.Instruction = 0x82;
    _lsmWrite.Module_ID = moduleID;
    _lsmWrite.Parameter1 = torque;
    _lsmWrite.Parameter2 = tPosition>>8;
    _lsmWrite.Parameter3 = tPosition;

    lsmSend();
}

/**
 * @brief  Action Move S_Position
 *
 * @param   uint8_t speed       0-250
 * @param   int16_t tPosition   target position, -500~500
 *
 */
void MrtLsmMicro::moveSposition(uint8_t speed, int16_t tPosition) {
    _lsmWrite.Instruction = 0x83;
    _lsmWrite.Parameter1 = speed;
    _lsmWrite.Parameter2 = tPosition>>8;
    _lsmWrite.Parameter3 = tPosition;

    lsmSend();
}

/**
 * @brief  action LED control
 *
 * @param   uint8_t moduleID     1-20
 * @param   uint8_t red         0-200
 * @param   uint8_t green       0-200
 * @param   uint8_t blue        0-200
 *
 */
void MrtLsmMicro::ledControl(uint8_t moduleID, uint8_t red, uint8_t green, uint8_t blue) {
    _lsmWrite.Module_ID = moduleID;
    _lsmWrite.Instruction = 0x84;
    _lsmWrite.Parameter1 = red;
    _lsmWrite.Parameter2 = green;
    _lsmWrite.Parameter3 = blue;

    lsmSend();
}

/**
 * @brief  action LED control
 *
 * @param   uint8_t red     0-200
 * @param   uint8_t green   0-200
 * @param   uint8_t blue    0-200
 *
 */
void MrtLsmMicro::ledControl(uint8_t red, uint8_t green, uint8_t blue) {
    _lsmWrite.Instruction = 0x84;
    _lsmWrite.Parameter1 = red;
    _lsmWrite.Parameter2 = green;
    _lsmWrite.Parameter3 = blue;

    lsmSend();
}

/**
 * @brief  action wheel mode
 *
 * @param   uint8_t cw      direction (CW:1, CCW:2)
 * @param   uint8_t speed   wheel speed, 0~100%, 2byte
 *
 */
void MrtLsmMicro::wheelMode(uint8_t cw, uint8_t speed) {
    //_lsmWrite.Module_ID = id;
    _lsmWrite.Instruction = 0x87;
    _lsmWrite.Parameter1 = cw;
    _lsmWrite.Parameter2 = speed >> 8;   // enter the High 8 bits in the value
    _lsmWrite.Parameter3 = speed;        // enter the Low 8 bits in the value

    lsmSend();
}

/**
 * @brief  action wheel mode
 *
 * @param   uint8_t moduleID    1-20
 * @param   uint8_t cw          direction (CW:1, CCW:2)
 * @param   uint8_t speed       wheel speed, 0~100%, 2byte
 *
 */
void MrtLsmMicro::wheelMode(uint8_t moduleID, uint8_t cw, uint8_t speed) {
    _lsmWrite.Module_ID = moduleID;
    _lsmWrite.Instruction = 0x87;
    _lsmWrite.Parameter1 = cw;
    _lsmWrite.Parameter2 = speed >> 8;   // enter the High 8 bits in the value
    _lsmWrite.Parameter3 = speed;        // enter the Low 8 bits in the value

    lsmSend();
}

/**
 * @brief   Action Active Stop (강제 정지)
 *
 *
 * @param   uint8_t moduleID    1-20
 */
void MrtLsmMicro::activeStop(uint8_t moduleID) {
    _lsmWrite.Module_ID = moduleID;
    _lsmWrite.Instruction = 0x88;
    _lsmWrite.Parameter1 = 0;
    _lsmWrite.Parameter2 = 0;
    _lsmWrite.Parameter3 = 0;

    lsmSend();
}

/**
 * @brief  Action Active Stop (강제 정지)
 *
 *
 */
void MrtLsmMicro::activeStop() {
    _lsmWrite.Instruction = 0x88;
    _lsmWrite.Parameter1 = 0;
    _lsmWrite.Parameter2 = 0;
    _lsmWrite.Parameter3 = 0;

    lsmSend();
}

/**
 * @brief  Action Passive Stop (power off)
 *
 *
 */
void MrtLsmMicro::passiveStop() {
    _lsmWrite.Instruction = 0x89;
    _lsmWrite.Parameter1 = 0;
    _lsmWrite.Parameter2 = 0;
    _lsmWrite.Parameter3 = 0;

    lsmSend();
}
