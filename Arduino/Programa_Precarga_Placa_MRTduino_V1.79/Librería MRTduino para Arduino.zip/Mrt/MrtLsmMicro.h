/**
 * @file     MrtLsmMicro.h
 * @author   keunja kim
 * @version  v0.5.0
 * @date     2017.03.23
 *
 */
#ifndef MRT_LSM_MICRO_H
#define MRT_LSM_MICRO_H

#include <Arduino.h>

#define kDirPin 11  ///< direction control i/o pin

typedef struct {
    unsigned char Header = 0xFF;
    unsigned char Product_ID = 0xB0;    ///< LSM-micro
    unsigned char Module_ID = 0;
    unsigned char Instruction = 0;
    unsigned char Parameter1 = 0;
    unsigned char Parameter2 = 0;
    unsigned char Parameter3 = 0;
    unsigned char CheckSum = 0;
} lsmTypeDef;

class MrtLsmMicro {
public:
    MrtLsmMicro();
    MrtLsmMicro(uint8_t moduleID);

    /**
     * @brief  send packet
     *
     *
     */
    void lsmSend();

    /**
     * @brief  recieve packet
     *
     *
     */
    void lsmGet();


    /**
     * @brief  get value check
     *
     *
     */
    long valueCheck();

    /**
     * @brief  get Module ID, 0-253, 2byt
     *
     *
     */
    uint8_t getModuleID();

    /**
     * @brief  get Module ID, 0-253, 2byte
     *
     * @return baudrate 2400 ~ 1000000 bps
     */
    unsigned long getBaudrate();

    /**
     * @brief  Action EEP PROG Config Data
     *
     *
     */
    void EEPconfig();

    /**
     * @brief  Action Move T_Position
     *
     * @param   uint8_t torque       0-250
     * @param   int16_t tPosition   target position, -500~500
     *
     */
    void moveTposition(uint8_t torque, int16_t tPosition);

    /**
     * @brief  Action Move T_Position
     *
     * @param   uint8_t moduleID     1-20
     * @param   uint8_t torque       0-250
     * @param   int16_t tPosition   target position, -500~500
     *
     */
    void moveTposition(uint8_t moduleID, uint8_t torque, int16_t tPosition);

    /**
     * @brief  Action Move S_Position
     *
     * @param   uint8_t speed       0-250
     * @param   int16_t tPosition   target position, -500~500
     *
     */
    void moveSposition(uint8_t speed, int16_t tPosition);

    /**
     * @brief  action LED control
     *
     * @param   uint8_t red     0-250
     * @param   uint8_t green   0-250
     * @param   uint8_t blue    0-250
     *
     */
    void ledControl(uint8_t red, uint8_t green, uint8_t blue);

    /**
     * @brief  action LED control
     *
     * @param   uint8_t moduleID     1-20
     * @param   uint8_t red         0-200
     * @param   uint8_t green       0-200
     * @param   uint8_t blue        0-200
     *
     */
    void ledControl(uint8_t moduleID, uint8_t red, uint8_t green, uint8_t blue);

    /**
     * @brief  action wheel mode
     *
     * @param   uint8_t cw      direction (CW:1, CCW:2)
     * @param   uint8_t speed   wheel speed, 0~100%, 2byte
     *
     */
    void wheelMode(uint8_t cw, uint8_t speed);

    /**
     * @brief  action wheel mode
     *
     * @param   uint8_t moduleID    1-20
     * @param   uint8_t cw          direction (CW:1, CCW:2)
     * @param   uint8_t speed       wheel speed, 0~100%, 2byte
     *
     */
    void wheelMode(uint8_t moduleID, uint8_t cw, uint8_t speed);

    /**
     * @brief  Action Active Stop (강제 정지)
     *
     *
     */
    void activeStop();

    /**
     * @brief   Action Active Stop (강제 정지)
     *
     *
     * @param   uint8_t moduleID    1-20
     */
    void activeStop(uint8_t moduleID);

    /**
     * @brief  Action Passive Stop (power off)
     *
     *
     */
    void passiveStop();

private:
    unsigned char _micro_write[8] = {0,};   ///< CTRL->LSM data
    int _micro_recieve[8] = {0,};           ///< LSM->CTRL data
    lsmTypeDef _lsmWrite;                   ///< CTRL->LSM data
};
#endif // MRT_LSM_MICRO_H
