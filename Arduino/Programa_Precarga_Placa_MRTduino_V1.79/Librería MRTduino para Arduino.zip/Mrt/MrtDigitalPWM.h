/**
  @file     MrtDigitalPWM.h
  @version  v1.0.6
  @date     2018.02.23
  @details  일반적인 Digital PWM 처리 \n
*/
#include "MrtCommon.h"

#ifndef MRT_DIGITAL_PWM_H
#define MRT_DIGITAL_PWM_H

class MrtDigitalPWM {
  public:
    MrtDigitalPWM();
    MrtDigitalPWM(int8_t port_no);
    void initDigitalPWM(int8_t port_no);
    void runPWM(int8_t pwm);

  private:
    int _pinNo;
};
#endif // MRT_DIGITAL_PWM_H
