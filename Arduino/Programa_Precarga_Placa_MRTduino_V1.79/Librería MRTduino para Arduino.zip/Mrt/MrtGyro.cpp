/**
* @file     MrtGyro.cpp
* @author   Jongsuk Lee
* @version  v0.3.0
* @date     2017.08.14
* @details  자이로 센서 (GY_521모듈)
*/
#include <Wire.h>
#include "MrtGyro.h"
#include <arduino.h>

volatile accel_t_gyro_union accel_t_gyro;

/**
 * @brief  센서 초기화
 */
void MrtGyro::initGyro()
{
  Wire.begin();      //Wire 라이브러리 초기화

  Wire.beginTransmission(MPU6050_I2C_ADDRESS); //MPU로 데이터 전송 시작
  Wire.write(PWR_MGMT_1);  // PWR_MGMT_1 register의 주소
  Wire.write(0);     //MPU-6050 시작 모드로
  Wire.endTransmission(true);


  // gyro scale
  Wire.beginTransmission(MPU6050_I2C_ADDRESS);
  Wire.write(GYRO_CONFIG_REG);  // gyro config register, full-scale range +/- 250 degrees/sec, 500, 1000, 2000
  Wire.write(0xF8);     //
  Wire.endTransmission(true);

  // acc scale
  Wire.beginTransmission(MPU6050_I2C_ADDRESS);
  Wire.write(ACCEL_CONFIG_REG);  // accel config register, full-scale range +/- 16384, 8192, 4096, 2048
  Wire.write(0xF8);     //
  Wire.endTransmission(true);

#if defined(USE_KALMAN_FILTER) // use kalman_filter
  // 보정위해 초기화
  initGyroKalman(&angX, Q_angle, Q_gyro, R_angle);
  initGyroKalman(&angY, Q_angle, Q_gyro, R_angle);
  initGyroKalman(&angZ, Q_angle, Q_gyro, R_angle);
#endif
}

/**
 * @brief  센서 값 읽기
 */
void MrtGyro::readData()
{
  int8_t tmp;
  Wire.beginTransmission(MPU6050_I2C_ADDRESS);  // 데이터 전송시작
  Wire.write(ACCEL_XOUT_H);                     // register 0x3B (ACCEL_XOUT_H) (X축 상위1바이트 주소가 0x3B), 큐에 데이터 기록
  Wire.endTransmission(false);                  // 연결유지
  Wire.requestFrom(MPU6050_I2C_ADDRESS,14,true);  // MPU에 데이터 요청 (14묶음의 데이터 요청)

  //데이터 한 바이트 씩 읽어서 반환
  tmp = Wire.read();
  
  accel_t_gyro.value.x_accel     = tmp<<8|Wire.read();  // 0x3B (ACCEL_XOUT_H) & 0x3C (ACCEL_XOUT_L)
  //accel_t_gyro.value.x_accel     = Wire.read()<<8|Wire.read();  // 0x3B (ACCEL_XOUT_H) & 0x3C (ACCEL_XOUT_L)
  accel_t_gyro.value.y_accel     = Wire.read()<<8|Wire.read();  // 0x3D (ACCEL_YOUT_H) & 0x3E (ACCEL_YOUT_L)
  accel_t_gyro.value.z_accel     = Wire.read()<<8|Wire.read();  // 0x3F (ACCEL_ZOUT_H) & 0x40 (ACCEL_ZOUT_L)
  accel_t_gyro.value.temperature = Wire.read()<<8|Wire.read();  // 0x41 (TEMP_OUT_H) & 0x42 (TEMP_OUT_L)
  accel_t_gyro.value.x_gyro      = Wire.read()<<8|Wire.read();  // 0x43 (GYRO_XOUT_H) & 0x44 (GYRO_XOUT_L)
  accel_t_gyro.value.y_gyro      = Wire.read()<<8|Wire.read();  // 0x45 (GYRO_YOUT_H) & 0x46 (GYRO_YOUT_L)
  accel_t_gyro.value.z_gyro      = Wire.read()<<8|Wire.read();  // 0x47 (GYRO_ZOUT_H) & 0x48 (GYRO_ZOUT_L)
}




/**************************************************
 * Sensor read/write
 **************************************************/
/**
 * @brief  MPU6050에서 데이터 읽기
 *
 * @param  int      start    읽을 위치
 *         uint8_t  *buffer  읽은 내용 저장할 버퍼
 *         int      size     읽을 크기
 * @return int      n        0 : 정상적으로 읽은 경우
 */
int MrtGyro::MPU6050_read(int start, uint8_t *buffer, int size)
{
	int i, n, error;

	Wire.beginTransmission(MPU6050_I2C_ADDRESS);

	n = Wire.write(start);
	if (n != 1)
		return (-10);

	n = Wire.endTransmission(false); // hold the I2C-bus
	if (n != 0)
		return (n);

	// Third parameter is true: relase I2C-bus after data is read.
	Wire.requestFrom(MPU6050_I2C_ADDRESS, size, true);

	i = 0;
	while(Wire.available() && i<size)
	{
		buffer[i++]=Wire.read();
	}

	if ( i != size)
		return (-11);
	return (0); // return : no error
}

/**
 * @brief  MPU6050에서 데이터 쓰기
 *
 * @param  int      start    기록할 위치
 *         uint8_t  *buffer  기록할 내용 저장된 버퍼
 *         int      size     기록할 크기
 * @return int      n        0 : 정상적으로 기록된 경우
 */
int MrtGyro::MPU6050_write(int start, const uint8_t *pData, int size)
{
	int n, error;

	Wire.beginTransmission(MPU6050_I2C_ADDRESS);

	n = Wire.write(start); // write the start address
	if (n != 1)
		return (-20);

	n = Wire.write(pData, size); // write data bytes
	if (n != size)
		return (-21);

	error = Wire.endTransmission(true); // release the I2C-bus
	if (error != 0)
		return (error);
	return (0); // return : no error
}

int MrtGyro::MPU6050_write_reg(int reg, uint8_t data)
{
	int error;
	error = MPU6050_write(reg, &data, 1);
	return (error);
}

/**
 * @brief  MPU6050_read로 읽은 값을 accel_t_gyro.value... 으로 사용하고자 할때 high, low bit 바꿔줌
 *
 */
void MrtGyro::MrtSwap()
 {
    uint8_t tmp;
    SWAP (accel_t_gyro.reg.x_accel_h, accel_t_gyro.reg.x_accel_l);
    SWAP (accel_t_gyro.reg.y_accel_h, accel_t_gyro.reg.y_accel_l);
    SWAP (accel_t_gyro.reg.z_accel_h, accel_t_gyro.reg.z_accel_l);
    SWAP (accel_t_gyro.reg.t_h, accel_t_gyro.reg.t_l);
    SWAP (accel_t_gyro.reg.x_gyro_h, accel_t_gyro.reg.x_gyro_l);
    SWAP (accel_t_gyro.reg.y_gyro_h, accel_t_gyro.reg.y_gyro_l);
    SWAP (accel_t_gyro.reg.z_gyro_h, accel_t_gyro.reg.z_gyro_l);

 }

/**
 * @brief  gyro 특정 축 값 읽기
 * @param  uint8_t  xyz_flag  gyro 축 (0:x축, 1:y축, 2:z축)
 * @return int      value
 */
int MrtGyro::getAxisValue(uint8_t xyz_flag) {
    int value = 0;

    if (_isStart) {
        initGyro();
        readData();

        _isStart = false;
    }

    delay(10);
    value = getAxisAt(xyz_flag);

    if (value == 0) {
        initGyro();
        readData();

        delay(10);
        value = getAxisAt(xyz_flag);
        
    }

    return value;
}

/**
 * @brief  gyro 특정 축 값 읽기
 * @param  uint8_t  xyz_flag  gyro 축 (0:x축, 1:y축, 2:z축)
 * @return int      value
 */
int MrtGyro::getAxisAt(uint8_t xyz_flag) {
    int value = 0;

    // gyro x
    if (xyz_flag == 0) {
        value = accel_t_gyro.value.x_gyro;
    }
    // gyro y
    else if (xyz_flag == 1) {
        value = accel_t_gyro.value.y_gyro;
    }
    // gyro z
    else if (xyz_flag == 2) {
        value = accel_t_gyro.value.z_gyro;
    }

    return value;
}

#if defined(USE_KALMAN_FILTER) // use kalman_filter
/**
 * @brief  칼만필터 적용해서 보정된 값을 추출
 *
 * @param  int *_gx1  보정 후 x축 값
 *         int *_gy1  보정 후 y축 값
 *         int *_gz1  보정 후 z축 값
 */
void MrtGyro::Kalman_filter(int *_gx1, int *_gy1, int *_gz1)
{
    int gx1=0, gy1=0, gz1 = 0;
    float gx2=0, gy2=0, gz2 = 0;
    int loopTime=0;

	/////////////////////////////////////////////////////////////////////////////
	//  칼만필터 적용해서 보정된 값을 추출하는 루틴
	/////////////////////////////////////////////////////////////////////////////
	
		curSensoredTime = millis();
		loopTime = curSensoredTime - prevSensoredTime;

		gx2 = angleInDegrees(lowX, highX, accel_t_gyro.value.x_gyro);
		gy2 = angleInDegrees(lowY, highY, accel_t_gyro.value.y_gyro);
		gz2 = angleInDegrees(lowZ, highZ, accel_t_gyro.value.z_gyro);

		predict(&angX, gx2, loopTime);
		predict(&angY, gy2, loopTime);
		predict(&angZ, gz2, loopTime);

		gx1 = update(&angX, accel_t_gyro.value.x_accel) / 10;
		gy1 = update(&angY, accel_t_gyro.value.y_accel) / 10;
		gz1 = update(&angZ, accel_t_gyro.value.z_accel) / 10;

		/////////////////////////////////////////////////////////////////////////////
		//  최초 실행될 때 측정되는 n개의 값을 평균 => 이후 측정되는 값을 보정
		/////////////////////////////////////////////////////////////////////////////
		if(initIndex < initSize) {
			xInit[initIndex] = gx1;
			yInit[initIndex] = gy1;
			zInit[initIndex] = gz1;
			if(initIndex == initSize - 1) {
				int sumX = 0; int sumY = 0; int sumZ = 0;
				for(int k=1; k <= initSize; k++) {
					sumX += xInit[k];
					sumY += yInit[k];
					sumZ += zInit[k];
				}

				xCal -= sumX/(initSize -1);
				yCal -= sumY/(initSize -1);
				zCal = (sumZ/(initSize -1) - zCal);
			}
			initIndex++;
		}

		/////////////////////////////////////////////////////////////////////////////
		//  측정값에 따라 필요한 작업을 처리하는 루틴
		/////////////////////////////////////////////////////////////////////////////
		else {
			// 측정값 보정
  			gx1 += xCal;
  			gy1 += yCal;
		}
        *_gx1 = gx1;
        *_gy1 = gy1;
        *_gz1 = gz1;

	prevSensoredTime = curSensoredTime;

}


/**************************************************
 * Raw data processing
 **************************************************/
float MrtGyro::angleInDegrees(int lo, int hi, int measured) {
	float x = (hi - lo)/180.0;
	return (float)measured/x;
}

void MrtGyro::initGyroKalman(struct GyroKalman *kalman, const float Q_angle, const float Q_gyro, const float R_angle) {
	kalman->Q_angle = Q_angle;
	kalman->Q_gyro = Q_gyro;
	kalman->R_angle = R_angle;

	kalman->P_00 = 0;
	kalman->P_01 = 0;
	kalman->P_10 = 0;
	kalman->P_11 = 0;
}

/*
* The kalman predict method.
* kalman 		the kalman data structure
* dotAngle 		Derivitive Of The (D O T) Angle. This is the change in the angle from the gyro.
* 					This is the value from the Wii MotionPlus, scaled to fast/slow.
* dt 				the change in time, in seconds; in other words the amount of time it took to sweep dotAngle
*/
void MrtGyro::predict(struct GyroKalman *kalman, float dotAngle, float dt) {
	kalman->x_angle += dt * (dotAngle - kalman->x_bias);
	kalman->P_00 += -1 * dt * (kalman->P_10 + kalman->P_01) + dt*dt * kalman->P_11 + kalman->Q_angle;
	kalman->P_01 += -1 * dt * kalman->P_11;
	kalman->P_10 += -1 * dt * kalman->P_11;
	kalman->P_11 += kalman->Q_gyro;
}

/*
* The kalman update method
* kalman 	the kalman data structure
* angle_m 	the angle observed from the Wii Nunchuk accelerometer, in radians
*/
float MrtGyro::update(struct GyroKalman *kalman, float angle_m) {
	const float y = angle_m - kalman->x_angle;
	const float S = kalman->P_00 + kalman->R_angle;
	const float K_0 = kalman->P_00 / S;
	const float K_1 = kalman->P_10 / S;
	kalman->x_angle += K_0 * y;
	kalman->x_bias += K_1 * y;
	kalman->P_00 -= K_0 * kalman->P_00;
	kalman->P_01 -= K_0 * kalman->P_01;
	kalman->P_10 -= K_1 * kalman->P_00;
	kalman->P_11 -= K_1 * kalman->P_01;
	return kalman->x_angle;
}

#endif  //  end of use kalman_filter
