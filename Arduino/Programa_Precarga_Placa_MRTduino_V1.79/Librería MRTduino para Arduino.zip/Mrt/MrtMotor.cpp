/*
   @file     :   MrtMotor.cpp
   @version  :   v1.0.6
   @date     :   2018.02.23
   @details  :   Motor driven
*/

#include "MrtMotor.h"

MrtMotor::MrtMotor() {
  SoftPWMBegin();
}

/*
   @brief finish soft pwm
*/
void MrtMotor::endMotor(void) {
  SoftPWMEnd(_motorPinNo);
}

/*
   @brief  DC Motor driven
   @param  int8_t  speed : speed (-100~100)
*/
void MrtMotor::runMotor(int8_t speed)
{
  if (speed <= 0) digitalWrite(_directionPinNo, LOW); // backward
  else digitalWrite(_directionPinNo, HIGH);           // forward

  SoftPWMSet(_motorPinNo, abs(speed));
}

/*
   @brief  run DC motor
   @param   uint8_t port  port number (1: ML1, 2: MR1, 3: ML2, 4: MR2)
   @param   int speed (-255 ~ 255)
*/
void MrtMotor::runMotor(uint8_t port, int speed) {
  if (port < 1) return;
  else _motorPinNo = port - 1;

  int motorPins[4][2] = {{3, 7}, {2, 4}, {1, 8}, {0, 6}};

  pinMode(motorPins[_motorPinNo][0], OUTPUT);
  pinMode(motorPins[_motorPinNo][1], OUTPUT);

  if (speed <= 0) digitalWrite(motorPins[_motorPinNo][0], LOW); // backward
  else digitalWrite(motorPins[_motorPinNo][0], HIGH);           // forward

  SoftPWMSet(motorPins[_motorPinNo][1], abs(speed));
}

/*
   @brief  Motor stop
*/
void MrtMotor::stopMotor() {
  digitalWrite(_directionPinNo, LOW);
  SoftPWMSet(_motorPinNo, 0);
  SoftPWMEnd(_motorPinNo);
}
