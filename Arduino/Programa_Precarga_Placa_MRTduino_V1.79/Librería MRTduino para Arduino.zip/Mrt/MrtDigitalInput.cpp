/**
* @file     MrtDigitalInput.cpp
* @version  v0.2.0
* @date     2016.09.26
* @details  일반적인 Digital Input 센서 처리 \n
*           Sensed    => HIGH \n
*           no-Sensed => LOW
*/

#include "MrtDigitalInput.h"

MrtDigitalInput::MrtDigitalInput() {}

/**
 * @brief  센서 초기화
 *
 * @param   uint8_t port_no : 포트번호
 *
 */
MrtDigitalInput::MrtDigitalInput(int8_t port_no) {
    initDigitalInput(port_no);
}

/**
 * @brief  센서 초기화
 *
 * @param   uint8_t port_no : 포트번호
 *
 */
void MrtDigitalInput::initDigitalInput(int8_t port_no)
{
    _pinNo = convertPinNumberInt(port_no);
    _delay_ms = 0;
    _last_readtime = 0;
    pinMode(_pinNo, INPUT);
}


/**
 * @brief  센서값을 읽고,  감지 여부 확인
 *
 * @param    bool  flag  : 감지(1)/미감지(0) 여부 체크함.
 * @return   bool  ret   : flag값 체크 결과
 *
 */
bool MrtDigitalInput::isSensed(bool flag)
{
    int8_t val=DIGITAL_INPUT_NO_SENSED;

    val = readValue();

    if(val == flag)
    {
        return true;
    } else {
        return false;
    }
}

/**
 * @brief  센서값을 읽기
 *
 * @return   uint8_t  val : 센서값
 *
 */
int8_t MrtDigitalInput::readValue()
{
    int8_t val;

    val=digitalRead(_pinNo);
    return val;
}
