/**
 * @file        MrtBuzzer.cpp
 * @version     v0.5.0
 * @date        2017.08.18
 * @details     Buzzer Sensor 정의 \n
 *              io type     : digital OUTPUT \n
 *              value scope : ON/OFF
 */
#include "MrtBuzzer.h"

MrtBuzzer::MrtBuzzer() {}

/**
 * @brief  센서 초기화
 *
 * @param   uint8_t         port_no    :  포트번호
 *
 */
MrtBuzzer::MrtBuzzer(int8_t port_no) {
    initBuzzer(port_no);
}

/**
 * @brief  센서 초기화
 *
 * @param   uint8_t         port_no    :  포트번호
 *
 */
void MrtBuzzer::initBuzzer(int8_t port_no)
{
    if (port_no == 13 || port_no == 14) {
        disableI2C();
    }

    _pinNo = convertPinNumberInt(port_no);
    pinMode(_pinNo, OUTPUT);
}

/**
 * @brief   Buzzer 켜기
 */
void MrtBuzzer::buzzerOn()
{
    digitalWrite(_pinNo, MRT_BUZZER_ON);
}

/**
 * @brief   Buzzer 끄기
 */
void MrtBuzzer::buzzerOff()
{
    digitalWrite(_pinNo, MRT_BUZZER_OFF);

}

/**
 * @brief   버져 ON/OFF
 *
 * @param   int flag    : on(1)/off(0) 스위치
 */
void MrtBuzzer::runBuzzer(int flag)
{
    if( flag == 0)  buzzerOff();
    else            buzzerOn();
}

/**
 * @brief   play buzzer, speaker
 *
 * @param   unsigned int    frequency  : 출력 주파수 in hertz
 * @param   unsigned long   duration   : 지속시간 in milliseconds
 *
 */
void MrtBuzzer::tone2(unsigned int frequency, unsigned long duration) {
    // pin 9 : not pwm
    switch (_pinNo) {
        case 5:
        case 11:
        case 3: {
            tone(_pinNo, frequency, duration);
            delay(duration);
            noTone(_pinNo);
        }
        break;
        default:
            buzzerTone2(frequency, duration);
            break;
    }//switch
}

/**
 * @brief   지정된 주파수를 가진 구형파(square wave) 출력 \n
 *          duty cycle 50% \n
 *          예를들면, 도는 digital on/off를 261번 해야한다. 이때 frequency가 261이 된다.
 *
 * @param   unsigned int    frequency  : 출력 주파수 in hertz
 * @param   unsigned long   duration   : 지속시간 in milliseconds
 *
 */
int MrtBuzzer::buzzerTone(unsigned int frequency, unsigned long duration) {
    if (_pinNo < 0)     return -1;
    if (frequency == 0) return -1;

    long period = 1000000L / frequency;
    long pulse = period / 2;  // duty cycle 50%
    unsigned long i=0, cntDuration=(duration*1000L);

    TIMSK1 = 0;          // ir remote timer1 충돌, disable
    SoftPWMDisable();

    for (i=0; i<cntDuration; i+=period) {
		digitalWrite(_pinNo, HIGH);
		delayMicroseconds(pulse);
		digitalWrite(_pinNo, LOW);
		delayMicroseconds(pulse);
	}
    delay(duration);

    SoftPWMEnable();
    TIMSK1 |= _BV(OCIE1A);   

    return 1;
}

/**
 * @brief   지정된 주파수를 가진 구형파(square wave) 출력 \n
 *          duty cycle 50% \n
 *          예를들면, 도는 digital on/off를 261번 해야한다. 이때 frequency가 261이 된다.
 *
 * @param   uint16_t    frequency  : 출력 주파수 in hertz
 * @param   uint16_t   duration   : 지속시간 in milliseconds
 *
 */
int MrtBuzzer::buzzerTone2(uint16_t frequency, uint16_t duration) {
    // input parameters: Arduino pin number, frequency in Hz, duration in milliseconds
    unsigned long startTime=millis();
    unsigned long halfPeriod= 1000000L/frequency/2;

    TIMSK1 = 0;          
    SoftPWMDisable();

    pinMode(_pinNo, OUTPUT);
    while (millis()-startTime< duration) {
        digitalWrite(_pinNo,HIGH);
        delayMicroseconds(halfPeriod);
        digitalWrite(_pinNo,LOW);
        delayMicroseconds(halfPeriod);
    }
    pinMode(_pinNo, INPUT);

    SoftPWMEnable();
    TIMSK1 = _BV(OCIE1A);   

    return 1;
}
