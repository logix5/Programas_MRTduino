

#ifndef   __COLOR_SENSOR_H__
#define  __COLOR_SENSOR_H__

#include <Arduino.h>

#define debuge_ 0


#define OUT_GPIO_DIR   DDRF
#define OUT_GPIO_LEV   PORTF
#define OUT_GPIO_STA   PINF
#define OUT_GPIO_PIN   PINF6

#define S2_GPIO_DIR   DDRF
#define S2_GPIO_LEV   PORTF
#define S2_GPIO_PIN   PORTF4

#define S3_GPIO_DIR   DDRF
#define S3_GPIO_LEV   PORTF
#define S3_GPIO_PIN   PORTF5

#define OUT         (OUT_GPIO_STA & (1<<OUT_GPIO_PIN))
#define S2_H        (S2_GPIO_LEV |=  (1 << S2_GPIO_PIN))
#define S2_L        (S2_GPIO_LEV &= ~(1 << S2_GPIO_PIN))
#define S3_H        (S3_GPIO_LEV |=  (1 << S3_GPIO_PIN))
#define S3_L        (S3_GPIO_LEV &= ~(1 << S3_GPIO_PIN))

#define OutputRedColor()    S2_L; S3_L
#define OutputGreenColor()  S2_H; S3_H
#define OutputBlueColor()   S2_L; S3_H

typedef enum
{
	Red_,
	Green_,
	Blue_,
	Cyan_,
	Magenta_,
	Yellow_,
	unknown_
}Color;


void White_Balance(void);
void Color_Sensor_Init(void);
unsigned char Color_Sensor(unsigned char color_data);

#endif 
 
